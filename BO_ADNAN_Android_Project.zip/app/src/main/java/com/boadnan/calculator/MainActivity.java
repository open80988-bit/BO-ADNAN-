package com.boadnan.calculator;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    LinearLayout root, keys;
    TextView expr, result;
    String current = "", previous = "";
    boolean justResult = false;

    int gold = Color.rgb(215,168,74);
    int panel = Color.rgb(17,21,29);
    int text = Color.rgb(247,244,236);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(9,11,16));
        getWindow().setNavigationBarColor(Color.rgb(9,11,16));
        build();
    }

    TextView tv(String s, float size, int color) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    GradientDrawable bg(int color, float r, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(r);
        if(strokeColor != 0) g.setStroke(1, strokeColor);
        return g;
    }

    void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22,20,22,18);
        root.setBackgroundColor(Color.rgb(9,11,16));

        TextView brand = tv("BO ADNAN", 25, gold);
        brand.setTypeface(null, 1);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, new LinearLayout.LayoutParams(-1,58));

        TextView line = tv("CALCULATOR  •  PREMIUM EDITION", 10, Color.rgb(143,150,163));
        line.setGravity(Gravity.CENTER);
        root.addView(line, new LinearLayout.LayoutParams(-1,28));

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL); screen.setGravity(Gravity.BOTTOM);
        screen.setPadding(22,16,22,18); screen.setBackground(bg(panel,28,Color.rgb(50,54,63)));
        expr = tv("",16,Color.rgb(143,150,163)); expr.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        result = tv("0",43,text); result.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        screen.addView(expr,new LinearLayout.LayoutParams(-1,38));
        screen.addView(result,new LinearLayout.LayoutParams(-1,70));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,0,1.15f);
        sp.setMargins(0,16,0,16); root.addView(screen,sp);

        keys = new LinearLayout(this); keys.setOrientation(LinearLayout.VERTICAL);
        String[][] rows={{"AC","⌫","%","÷"},{"7","8","9","×"},{"4","5","6","−"},{"1","2","3","+"},{"0",".","="}};
        for(String[] row:rows){
            LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER); r.setPadding(0,4,0,4);
            for(String k:row){
                Button b=button(k);
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,0,1);
                lp.setMargins(5,5,5,5);
                if(k.equals("0")) lp.weight=2;
                r.addView(b,lp);
            }
            keys.addView(r,new LinearLayout.LayoutParams(-1,0,1));
        }
        root.addView(keys,new LinearLayout.LayoutParams(-1,0,2.8f));
        setContentView(root);
    }

    Button button(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(20); b.setTextColor(text);
        b.setAllCaps(false); b.setPadding(0,0,0,0);
        int c = s.equals("=")?gold:(s.equals("AC")||s.equals("⌫")||s.equals("%")||s.equals("÷")||s.equals("×")||s.equals("−")||s.equals("+")?Color.rgb(30,35,44):Color.rgb(22,26,34));
        b.setBackground(bg(c,22,Color.rgb(52,57,67)));
        b.setOnClickListener(v -> press(s));
        return b;
    }

    void press(String s){
        if(s.equals("AC")){current="";previous="";justResult=false;update();return;}
        if(s.equals("⌫")){if(current.length()>0)current=current.substring(0,current.length()-1);update();return;}
        if(s.equals("=")){calculate();return;}
        if(s.equals("%")){try{double x=Double.parseDouble(current);current=fmt(x/100);update();}catch(Exception e){}return;}
        if(s.equals("÷")||s.equals("×")||s.equals("−")||s.equals("+")){
            if(current.length()==0)return;
            current+=s; justResult=false; update(); return;
        }
        if(justResult){current="";justResult=false;}
        if(s.equals(".") && current.endsWith(".")) return;
        current+=s; update();
    }

    void update(){
        expr.setText(current);
        result.setText(current.length()==0?"0":current);
    }

    void calculate(){
        if(current.contains("−")){
            showPrank();
            return;
        }
        try{
            double v=eval(current.replace("×","*").replace("÷","/").replace("−","-"));
            previous=current; current=fmt(v); justResult=true; update();
        }catch(Exception e){ result.setText("خطأ"); }
    }

    double eval(String s){
        java.util.Stack<Double> nums=new java.util.Stack<>();
        java.util.Stack<Character> ops=new java.util.Stack<>();
        int i=0;
        while(i<s.length()){
            if(Character.isDigit(s.charAt(i))||s.charAt(i)=='.'){
                int j=i; while(j<s.length()&&(Character.isDigit(s.charAt(j))||s.charAt(j)=='.'))j++;
                nums.push(Double.parseDouble(s.substring(i,j))); i=j; continue;
            }
            char op=s.charAt(i++);
            while(!ops.empty() && prec(ops.peek())>=prec(op)) apply(nums,ops.pop());
            ops.push(op);
        }
        while(!ops.empty()) apply(nums,ops.pop());
        return nums.pop();
    }
    int prec(char c){return (c=='+'||c=='-')?1:2;}
    void apply(java.util.Stack<Double> n,char o){
        double b=n.pop(),a=n.pop();
        n.push(o=='+'?a+b:o=='-'?a-b:o=='*'?a*b:a/b);
    }
    String fmt(double x){
        if(x==Math.rint(x)) return String.format(Locale.US,"%.0f",x);
        return String.format(Locale.US,"%.8f",x).replaceAll("0+$","").replaceAll("\\.$","");
    }

    void showPrank(){
        final Dialog d=new Dialog(this);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(28,30,28,24); box.setGravity(Gravity.CENTER);
        box.setBackground(bg(Color.rgb(17,21,29),30,Color.rgb(215,168,74)));
        TextView emoji=tv("🙂",48,text); emoji.setGravity(Gravity.CENTER);
        TextView title=tv("رسالة BO ADNAN",22,gold); title.setGravity(Gravity.CENTER);
        TextView msg=tv("انتظر لمدة 24 ساعة على الأقل",24,text);
        msg.setGravity(Gravity.CENTER); msg.setPadding(0,20,0,24);
        Button ok=button("حسنًا");
        box.addView(emoji,new LinearLayout.LayoutParams(-1,70));
        box.addView(title,new LinearLayout.LayoutParams(-1,55));
        box.addView(msg,new LinearLayout.LayoutParams(-1,100));
        box.addView(ok,new LinearLayout.LayoutParams(-1,58));
        ok.setOnClickListener(v->d.dismiss());
        d.setContentView(box);
        Window w=d.getWindow();
        if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent); w.setLayout(-1,-2);}
        d.show();
        if(d.getWindow()!=null)d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.86f),-2);
    }
}